// @flow weak

import React        from 'react';
import PropTypes    from 'prop-types';
import Button       from './button/Button';

const Header = ({
  appName,
  toggleSideMenu,
  onLogout
}) => (
  <header
    className="header fixed--header">
    <a href="#"
      className="logo">
      { appName }
    </a>
    <nav
      className="navbar navbar-static-top"
      role="navigation">
      <Button
        toggleSideMenu={toggleSideMenu}
      />
    </nav>
  </header>
);

Header.propTypes = {
  appName:        PropTypes.string,

  showPicture:    PropTypes.bool,
  onLogout:       PropTypes.func,

  currentView:    PropTypes.string,
  toggleSideMenu: PropTypes.func
};

Header.defaultProps = {
  appName: 'applicationName'
};

Header.displayName = 'Header';

export default Header;
