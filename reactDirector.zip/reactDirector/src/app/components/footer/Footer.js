// @flow weak

import React from 'react';

const Footer = () => (
  <div className="footer-main">
    EnQ Status Dashboard
  </div>
);

export default Footer;
