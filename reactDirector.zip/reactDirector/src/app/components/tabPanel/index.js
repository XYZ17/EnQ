// @flow weak

export { default as TabPanel }            from './tabPanel/TabPanel';
export { default as TabPanelHeader }      from './tabPanelHeader/TabPanelHeader';
export { default as TabPanelBody }        from './tabPanelBody/TabPanelBody';
export { default as TabPanelBodyContent } from './tabPanelBodyContent/TabPanelBodyContent';
export { default as TabPanelDemo }        from './TabPanelDemo';
